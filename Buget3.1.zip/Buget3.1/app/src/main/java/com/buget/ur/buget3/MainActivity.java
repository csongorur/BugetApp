package com.buget.ur.buget3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    private EditText name;
    private EditText money;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText) findViewById(R.id.txtName);
        money=(EditText) findViewById(R.id.txtMoney);
    }

    public void Add(View v)
    {
        AsyncTaskPostData asyncTaskPostData = new AsyncTaskPostData(this,name.getText().toString(),money.getText().toString(),"1");
        asyncTaskPostData.execute("http://evidentastudentilor.azurewebsites.net/Buget2/API/api.php");
        name.setText("");
        money.setText("");
    }

    public void Remove(View v)
    {
        AsyncTaskPostData asyncTaskPostData = new AsyncTaskPostData(this,name.getText().toString(),money.getText().toString(),"2");
        asyncTaskPostData.execute("http://evidentastudentilor.azurewebsites.net/Buget2/API/api.php");
        name.setText("");
        money.setText("");
    }
}
