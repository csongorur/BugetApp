package com.buget.ur.buget3;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ur on 2016.02.29..
 */
public class AsyncTaskPostData extends AsyncTask <String , Void , String>
{

    private Context context=null;
    private String name;
    private String money;
    private String tran;
    private String retVal="";
    private ProgressDialog progressDialog;

    public AsyncTaskPostData(Context context , String name , String money , String tran)
    {
        this.context=context;
        this.name=name;
        this.money=money;
        this.tran=tran;
    }

    @Override
    protected void onPreExecute()
    {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Pleas wait...");
        progressDialog.show();
    }

    @Override
    protected String doInBackground(String... params)
    {
        InputStream is=null;
        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(params[0]);

        List<NameValuePair> nameValuePairs = new ArrayList<>();
        nameValuePairs.add(new BasicNameValuePair("name",name));
        nameValuePairs.add(new BasicNameValuePair("money",money));
        nameValuePairs.add(new BasicNameValuePair("tran", tran));



        try
        {
            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpClient.execute(httpPost);

            if(response.getStatusLine().getStatusCode()== HttpStatus.SC_OK)
            {
                HttpEntity entity = response.getEntity();

                if(entity!=null)
                {
                    is=entity.getContent();

                    StringBuilder sb = new StringBuilder();

                    int chIn;

                    while((chIn=is.read())!=-1)
                    {
                        sb.append((char)chIn);
                    }
                    retVal=sb.toString();
                }
            }




        } catch (ClientProtocolException e)
        {
            retVal="Error: "+e.getMessage();
        } catch (IOException e)
        {
            retVal="Error: "+e.getMessage();
        }
        finally
        {
            if(is!=null)
            {
                try
                {
                    is.close();
                } catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }

        return retVal;
    }


    @Override
    protected void onPostExecute(String s)
    {
        progressDialog.dismiss();
        Toast.makeText(context,s,Toast.LENGTH_LONG).show();
    }
}
